import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';
import { HttpClient } from '@angular/common/http';
import { Address } from './address';
import { ICategoryMaster } from './icategory-master';
@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  url = "http://localhost:8080";
  constructor(private _http: HttpClient) {
  }

  public loginUserFromRemote(user: User): Observable<any> {
    return this._http.post<any>(this.url + "/Login", user)
  }
  public registerUserFromRemote(user: User): Observable<any> {
    return this._http.post<any>(this.url + "/doRegister", user)
  }
  getSubCat(): Observable<ICategoryMaster[]> {
    return this._http.get<ICategoryMaster[]>(this.url+"/allCategories");
  }
  getProducts(categoryMasterId: number): Observable<any> {
    return this._http.get<any>(this.url+"/getAllProducts/" + categoryMasterId)
  }
  getProductById(ProductId: number): Observable<any> {
    return this._http.get<any>(this.url +"/getProductById/"+ ProductId)
  }
  getSubCatByName(subcat: string): Observable<any> {
    return this._http.get<any>(this.url +"/allSubCategories/"+ subcat);
  }
}


