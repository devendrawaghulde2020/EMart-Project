import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { CategoryMaster } from '../category-master';
import { ICategoryMaster } from '../icategory-master';
import { Product } from '../product';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {
  electronics!: any[];
  Products!: Product[];
  constructor(private _service: RegistrationService, private router: Router) { }

  ngOnInit(): void {
    this._service.getSubCatByName("ELE").subscribe(data => this.electronics = data);
  }
  onclickimg(str: any): void {
    
      if (str.flag == 0) {
        this._service.getSubCatByName(str.subCategoryName).subscribe(data => this.electronics = data);//fetch categories
      }
      else if (str.flag == 1) {
        this._service.getProducts(str.categoryMasterId).subscribe(data => this.Products = data);//fetch products
      }
    }
  
}
