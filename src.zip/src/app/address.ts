export class Address {
      shippingAddressId!: number;
	  address!: string;
	  city!: string;
	  state!: string;
	  pincode!: string;
	  country!: string;
}
