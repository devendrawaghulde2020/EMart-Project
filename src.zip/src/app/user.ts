export class User {
   
      userId!: number;
	  firstName!:string;
	  lastName!:string;
	  customerPhone!:string;
	  emailId!:string;
	  username!:string;
	  password!:string;
	  royalFlag!:boolean;
	 // shippingAddress!: string;
    constructor( ){
   
    }
    
}
