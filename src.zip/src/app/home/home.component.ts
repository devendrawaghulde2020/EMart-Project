import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { CategoryMaster } from '../category-master';
import { ICategoryMaster } from '../icategory-master';
import { Product } from '../product';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  categoryData!: any[];
  Products!: Product[];
  constructor(private _service: RegistrationService, private router: Router) {
    console.log(this.categoryData);
  }
  ngOnInit(): void {
    this._service.getSubCat().subscribe(data => this.categoryData = data);
  }
  onclickimg(str: any): void 
  {
      if (str.flag == 0) 
      {
        this.categoryData = [];
        console.log(str+" "+str.flag)
        this._service.getSubCatByName(str.categoryId).subscribe(
          data => this.categoryData = data);//fetch categories
      }
      else if (str.flag == 1) 
      {
        this.categoryData = [];
        this._service.getProducts(str.categoryMasterId).subscribe(
          data => this.Products = data);//fetch products
      }
    
  }
}




