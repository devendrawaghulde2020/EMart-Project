import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {NgForm } from  '@angular/forms';
import { Router } from '@angular/router';
import { Address } from '../address';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  address= new Address();
  msg:any;
  user= new User();
  constructor(private _service: RegistrationService, private _router: Router) { }

  ngOnInit(): void {

  }


  registerUser(){
    this._service.registerUserFromRemote(this.user).subscribe((data)=>this.msg=data)
      this._router.navigate(["/login"]);
    
  }

}
