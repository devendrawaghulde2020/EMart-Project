import { ICategoryMaster } from "./icategory-master";

export class CategoryMaster implements ICategoryMaster {
    constructor(
        public categoryMasterId: number,
        public categoryName: string,
        public categoryId: number,
        public subCategoryName: string,
        public subCategoryId: number,
        public ImagePath: string,
        public flag: number
    ) { }
}
