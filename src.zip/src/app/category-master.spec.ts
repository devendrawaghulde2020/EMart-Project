import { CategoryMaster } from './category-master';

describe('CategoryMaster', () => {
  it('should create an instance', () => {
    expect(new CategoryMaster()).toBeTruthy();
  });
});
