import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginsuccess',
  templateUrl: './loginsuccess.component.html',
  styleUrls: ['./loginsuccess.component.css']
})
export class LoginsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
/* ngOnInit(): void {
    let empCode: string = this.route.snapshot.params['id'];
    let acode: number = parseInt(empCode);
    this._Service.getProducts(acode).subscribe(data => this.product = data);
  }
}*/