export interface ICategoryMaster {
    categoryMasterId:number;
	categoryName:string;
	categoryId:number;
	subCategoryName:string;
	subCategoryId:number;
	ImagePath:string;
	flag:number;
}
