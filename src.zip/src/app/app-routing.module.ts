import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApparelsComponent } from './apparels/apparels.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductComponent } from './product-datails/product.component';
import { RegistrationComponent } from './registration/registration.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'loginsuccess', component: LoginsuccessComponent },
  { path: 'register', component: RegistrationComponent },
  { path: 'home', component: HomeComponent },
  { path: 'Electronics', component: ElectronicsComponent },
  { path: 'Apparels', component: ApparelsComponent },
  { path: 'products/:id', component: ProductComponent },
  { path: 'products', component: ProductComponent },
  { path: '*', component: PageNotFoundComponent },
  { path: '', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
