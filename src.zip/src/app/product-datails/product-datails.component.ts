import { Component, OnInit } from '@angular/core';
import { IProduct } from '../iproduct';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  pageTitle = 'Product Detail';
  product: any={productName:"Electr", productImagePath:"emartlogo.jfif", productDescription:"hdbfbdjd",unitStock:2,regularPrice:250,cardHolderPrice: 200,epoints:10,}
    
  constructor() { }
  ngOnInit(): void {
  }
}
 