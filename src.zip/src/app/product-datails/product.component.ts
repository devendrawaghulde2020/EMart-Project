import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IProduct } from '../iproduct';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  pageTitle = 'Product Detail';
  product!: IProduct;
  router: any;

  constructor(private _service: RegistrationService, private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let empCode: string = this._activatedRoute.snapshot.params['id'];
    let acode: number = parseInt(empCode);
    this._service.getProductById(acode).subscribe(data => this.product = data);
  }
  onBack(): void 
  {
    this.router.navigate(['/home']);
  }
}
