import { ICategoryMaster } from "./icategory-master";

export interface IProduct {
    productId: number;
    productDescription: string;
    productName: string;
    unitStock: number;
    regularPrice: number;
    cardHolderPrice: number;
    epoints: number;
    categoryMasterId: ICategoryMaster;
    productImagePath: string;
}
