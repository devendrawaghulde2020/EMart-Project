import { ICategoryMaster } from "./icategory-master";
import { IProduct } from "./iproduct";

export class Product implements IProduct {
    constructor(
        public productId: number,
        public productDescription: string,
        public productName: string,
        public unitStock: number,
        public regularPrice: number,
        public cardHolderPrice: number,
        public epoints: number,
        public categoryMasterId: ICategoryMaster,
        public productImagePath: string
    ) { }


}
